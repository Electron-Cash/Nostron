import threading
import asyncio
import datetime
from PyQt5.QtGui import *
from PyQt5.QtCore import *
from PyQt5.QtWidgets import *

from electroncash.i18n import _
from electroncash_gui.qt.util import MyTreeWidget, MessageBoxMixin, WindowModalDialog, Buttons, CancelButton,OkButton
from electroncash import util 
from electroncash.util import print_error

import sys
import time
import os
sys.path.insert(0,os.path.join(os.path.dirname(__file__),'monstr_terminal'))

from .monstrwrap import monstrwrap


class MyWidget(QTextEdit):
 
    def mousePressEvent(self, e):
        self.anchor = self.anchorAt(e.pos())
        if self.anchor:
            QApplication.setOverrideCursor(Qt.PointingHandCursor)

    def mouseReleaseEvent(self, e):
        if self.anchor:
            QDesktopServices.openUrl(QUrl(self.anchor))
            QApplication.setOverrideCursor(Qt.ArrowCursor)
            self.anchor = None


class Ui2(MyTreeWidget, MessageBoxMixin):

    
    
    receive_refresh_feed_trigger = pyqtSignal(str)

    def __init__(self, parent, plugin, wallet_name):
        # An initial widget is required.
        MyTreeWidget.__init__(self, parent, self.create_menu, [], 0, [])

        import os.path
        self.my_monstrwrap = monstrwrap(ui_window = self) 

        self.chat_history =""

        self.plugin = plugin
        self.wallet_name = wallet_name
        vbox = QVBoxLayout()
        vbox2 = QVBoxLayout()
        vbox3 = QVBoxLayout()
        vbox4 = QVBoxLayout()
        vbox5 = QVBoxLayout()
        vbox6 = QVBoxLayout()
        vbox7 = QVBoxLayout()
        vbox8 = QVBoxLayout()
        self.setLayout(vbox)
        
        
        label22 = QLabel(_("Available Groups:"))
        label22.setAlignment(Qt.AlignCenter)
        f = label22.font()
        f.setPointSize(18)  
        label22.setFont(f) 
        
        hbox22=QHBoxLayout()
        hbox22.addWidget(label22)
        vbox8.addLayout(hbox22)
        self.group_chat_listings_area= QTextBrowser()
         
        self.group_chat_listings_area.setOpenLinks(False)
        self.group_chat_listings_area.anchorClicked.connect(self.anchor_clicked)
        
        hbox8 = QHBoxLayout()
        hbox8.addWidget(self.group_chat_listings_area)
        vbox8.addLayout(hbox8) 
       
        label15 = QLabel(_("CHOOSE A RELAY"))
        
        label15.setAlignment(Qt.AlignRight)
        hbox15=QHBoxLayout()
        hbox15.addWidget(label15) 
        self.relays_combo = QComboBox() 
        self.relays_combo.currentIndexChanged.connect(self.on_relay_change)
        hbox15.addWidget(self.relays_combo)
        vbox8.addLayout(hbox15)
       
        self.check_available_group_chats_button = QPushButton(_("FETCH LIST OF GROUPS"))
        
        self.check_available_group_chats_button.clicked.connect(self.fetch_group_chats)
        hbox10=QHBoxLayout()
        hbox10.addWidget(self.check_available_group_chats_button)
        vbox8.addLayout(hbox10)
        
        label20 = QLabel(_("Group Chat:"))
        label20.setAlignment(Qt.AlignCenter)
        f = label20.font()
        f.setPointSize(18)  
        label20.setFont(f) 
        hbox20=QHBoxLayout()
        hbox20.addWidget(label20)
        vbox5.addLayout(hbox20)
        self.event_view_area= QTextEdit()
         
        
        hbox7 = QHBoxLayout()
        hbox7.addWidget(self.event_view_area)
        vbox5.addLayout(hbox7) 
        self.refresh_feed_button = QPushButton(_("REFRESH FEED"))
        hbox9=QHBoxLayout()
        hbox9.addWidget(self.refresh_feed_button)
        vbox5.addLayout(hbox9)
        my_line = QFrame()
        my_line.setLineWidth(3)
        my_line.setMidLineWidth(3)
        my_line.setFrameShape(QFrame.HLine)
        my_line.setFrameShadow(QFrame.Sunken)
        vbox5.addWidget(my_line)
        self.refresh_feed_button.clicked.connect(self.refresh_feed_view)
    
        # Chat message widgets
        self.chatarea = QTextEdit()
        self.my_chat_msg = QLineEdit()
        self.message_button = QPushButton(_("Send Message"))
        hbox3 = QHBoxLayout()
        self.message_button.clicked.connect(self.send_nostr_msg)
        hbox4 = QHBoxLayout()
        my_line2 = QFrame()
        my_line2.setLineWidth(3)
        my_line2.setMidLineWidth(3)
        my_line2.setFrameShape(QFrame.HLine)
        my_line2.setFrameShadow(QFrame.Sunken)
        vbox6.addWidget(my_line2)
        label21 = QLabel(_("Post Your Messages"))
        label21.setAlignment(Qt.AlignCenter)
        f = label21.font()
        f.setPointSize(18)  
        label21.setFont(f) 
        vbox6.addWidget(label21)
        hbox22 = QHBoxLayout()
        hbox22.addWidget(self.my_chat_msg)
        hbox22.addWidget(self.message_button)
        vbox6.addLayout(hbox22)
        
        
        ######################################################
       
   
        # Add remaining widgets
        
        vbox.addLayout(vbox8)   
        vbox.addLayout(vbox5)   
          
        vbox.addLayout(vbox7) 
        vbox.addLayout(hbox3)
        vbox.addLayout(hbox4) 
        vbox.addLayout(vbox6)
        
        # Set up trigger so we can call back into the ui from the p2pnetwork threads. 
        self.receive_refresh_feed_trigger.connect(self.process_refresh_feed_message)
         
        
        self.update_relays_list()
 
    def anchor_clicked(self,arg1):
        print ("ANCHOR CLICKED")    
        print ("arg1 is ",arg1)
        
         
            
    def doBech32Copy(self,txt):
        # This is a helper function to get the pubkey in bech32 format.
        txt=self.my_monstrwrap.Terminal.monstr.encrypt.Keys.hex_to_bech32(str(txt))
        self.doCopy(txt)

    def doCopy(self,txt):
        # This is a helper function for cliboard copy. copy_to_clipboard should be available from main_window so just call parent.
        txt = txt.strip() 
        self.parent.copy_to_clipboard(txt)

    
    def copy_pubkey(self):
        # This is a helper function to copy a key to the clipboard.
        pubkey=""           
        my_alias_list = self.parent.wallet.storage.get('nostron_aliases')
        chosen_alias = self.parent.wallet.storage.get('nostron_chosen_alias')
        chosen_alias_name = chosen_alias.get('chosen_alias')
        for i in my_alias_list:
            alias_name = i.get('alias') 
            if alias_name == chosen_alias_name:
                pubkey=i.get('pubkey')
        # Copy to clipboard  
        self.doBech32Copy(pubkey)
               
    # Functions for the plugin architecture.
    def create_menu(self):
        pass

    def on_delete(self):
        pass

    def on_update(self):
        pass
        
    def send_nostr_msg(self):
        # This function sends a message to the network.
        post_message = self.my_chat_msg.text()
        
        # Do not post empty messages, just exit.
        if post_message == "":
            return
               
        confirm_msg="Post this message to the network?"
        if self.question(confirm_msg):
            # Get the private key
            privkey=""           
            my_alias_list = self.parent.wallet.storage.get('nostron_aliases')
            chosen_alias = self.parent.wallet.storage.get('nostron_chosen_alias')
            chosen_alias_name = chosen_alias.get('chosen_alias')
            for i in my_alias_list:
                alias_name = i.get('alias') 
                if alias_name == chosen_alias_name:
                    privkey=i.get('privkey')
        
            # Get the Relays
            post_relay_list = []
            counter = 0
            relays = self.parent.wallet.storage.get('nostron_relays')
            if relays is None:
                return
            for i in relays:
                single_relay = i.get('relay')
                post_relay_list.append(single_relay) 
            try:
                asyncio.run(self.my_monstrwrap.Terminal.poster.run_post(post_message=post_message,post_relay=post_relay_list,priv_k=privkey))
            except:
                self.show_error("One or more relays failed to post.")
            self.my_chat_msg.setText("")
        
      
    def on_relay_change(self):
        # This is a function to update storage when the relays dropdown is selected.
        current_relay = self.relays_combo.currentText()
        nostron_chosen_relay=dict(chosen_relay = str(current_relay))
        self.parent.wallet.storage.put('nostron_chosen_relay', nostron_chosen_relay)
        self.parent.wallet.storage.write()
                     
    
    def update_relays_list(self):
        # This function updates the relays combo box widget
        my_relays_list = self.parent.wallet.storage.get('nostron_relays')
        relays_choices = []
        if my_relays_list is None: 
            return
        
        # Grab the selected choice from storage.
        chosen_relay_dict = self.parent.wallet.storage.get('nostron_chosen_relay')
        if chosen_relay_dict is None:
            chosen_relay_name = None
        else:
            chosen_relay_name = chosen_relay_dict.get('chosen_relay')
        
        # keep track of the qcombobox index so we can grab the right default value.
        my_index = 0
        chosen_index = 0
        
        for i in my_relays_list:
            relay_name = i.get('relay') 
            
            relays_choices.append(relay_name) 
            if relay_name == chosen_relay_name:
                chosen_index=my_index
            my_index +=1     
            
        self.relays_combo.clear()
        self.relays_combo.addItems(relays_choices)
        # Reflect chosen alias in the dropdown.
        self.relays_combo.setCurrentIndex(chosen_index)                 
        
    def fetch_group_chats(self):
    
        
        # Grab the selected relay from storage.
        chosen_relay_dict = self.parent.wallet.storage.get('nostron_chosen_relay')
        chosen_relay_name = chosen_relay_dict.get('chosen_relay')
        relay_list= []
        relay_list.append(str(chosen_relay_name))
        print ("FUBAR DEBUG chosen relay ",chosen_relay_name)
        try:
            
            events = asyncio.run( self.my_monstrwrap.Terminal.nostron_interface.fetch_group_chats(relays=relay_list))
                
        except:
            self.show_error("There was a problem fetching group chats from the relay.")
            return

        all_events =""
        event_dict = []
        for c_evt in events:
            event_dict.append({"created_at":c_evt._created_at,  "content":c_evt._content})
        def get_created_at(msg):
            return msg.get('created_at')
        # Sort by date stamp
        event_dict.sort(key=get_created_at)
        for i in event_dict:
            content = i.get('content')
            content_dict = dict(item.split(":") for item in content.split(","))
            print ("name is ",content_dict['name'])
            
            print ("content type is ", type(content))
            epoch_time=i.get('created_at')
            date_time = datetime.datetime.fromtimestamp( epoch_time )  
            event_text = str(date_time) + "  | "   + ": " + i.get('content') + "\r\n"
            all_events = all_events + event_text
        
        self.receive_group_chat_list_message(all_events) 
            
    def refresh_feed_view(self): 
    
        print ("FUBAR 3333333333")
        # This function refreshes the main window where user sees messages from friends.
        all_events = ""
        relay_list = []
        authors_list = []
        # Get the relays we are pulling from
        relays = self.parent.wallet.storage.get('nostron_relays')
 
        if relays is None:
            return
        for i in relays:
            relay_name = i.get('relay')
            relay_list.append(str(relay_name))
            
        # Get the pubkeys we are filtering on
        my_friend_list = self.parent.wallet.storage.get('nostron_friends')
        # Include our own aliases too...
        my_alias_list = self.parent.wallet.storage.get('nostron_aliases')
        my_friend_list = my_friend_list + my_alias_list
        if my_friend_list is None:
            return 
        for i in my_friend_list:
            pubkey=i.get('pubkey')          
            authors_list.append(pubkey)
        print ("FUBAR 6666666666666")
        try:
            
            events = asyncio.run( self.my_monstrwrap.Terminal.nostron_interface.fetch_events(relays=relay_list,authors=authors_list))
            
            
            ##############
            ## ATTEMPT TO ADD WAITING DIALOG SO THE USER DOESNT CLICK BUTTONS WHILE FETCH HAPPENS.
            #def task():
                #events = asyncio.run( self.my_monstrwrap.Terminal.nostron_interface.fetch_events())
            #WaitingDialog(self, _('Listening to Relays...'), task)
            
        except:
            self.show_error("One or more relays failed.")
            return
        
        print ("FUBAR 444444444444444")      
        event_dict = []
        for c_evt in events:
            
            #Start with the pubkey. who is this?
            display_name = ""
            pubkey = str(c_evt._pub_key)
            l = [] 
            for i in my_friend_list:
                friend_name = i.get('name')
                alias_name = i.get('alias')
                friend_pubkey = i.get('pubkey')
                if alias_name is not None:
                    friend_name = alias_name + "(me)"
                if pubkey == friend_pubkey:
                    display_name = friend_name

            event_dict.append({"created_at":c_evt._created_at, "display_name":str(display_name), "content":c_evt._content})
        def get_created_at(msg):
            return msg.get('created_at')
        # Sort by date stamp
        event_dict.sort(key=get_created_at)
        for i in event_dict:
            epoch_time=i.get('created_at')
            date_time = datetime.datetime.fromtimestamp( epoch_time )  
            event_text = str(date_time) + "  | " + i.get('display_name') + ": " + i.get('content') + "\r\n"
            all_events = all_events + event_text
           
        self.receive_refresh_feed_message(all_events) 
          
    # DEAL WITH INCOMING MESSAGES 
       
    def receive_refresh_feed_message(self,incoming_message):
        self.receive_refresh_feed_trigger.emit(str(incoming_message))
    
    
    def receive_group_chat_list_message(self,incoming_message):
        self.group_chat_list = incoming_message
        self.group_chat_listings_area.setText(self.group_chat_list)
      
    def process_refresh_feed_message(self,incoming_message): 
     
        self.feed_history = incoming_message
        self.event_view_area.setText(self.feed_history) 
        #print ("FUBAR INCOMING")
        #
        #
        #cursor = self.event_view_area.textCursor() 
  
        #fmt = cursor.charFormat()
        #fmt.setForeground(QColor('blue'))
        #address = 'http://example.com'
        #fmt.setAnchor(True)
        #fmt.setAnchorHref(address)
        ##fmt.setToolTip(address)
        #cursor.insertText("Hello world again", fmt)
        
        #cursor2 = self.event_view_area.textCursor() 
        #fmt2 = cursor2.charFormat()
        #fmt2.setForeground(QColor('black'))
        #fmt2.setAnchor(False)
        #fmt2.setAnchorHref("")
        #cursor2.insertText("Back in Black", fmt2)
        
        
        
                            
