from electroncash.i18n import _

fullname = 'nostron'
description = _('Nostr prototype plugin')
available_for = ['qt']
