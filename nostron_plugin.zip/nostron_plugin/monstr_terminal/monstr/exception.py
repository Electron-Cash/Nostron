class ConfigurationError(Exception):
    # unhappy about something we receive from the command line
    pass